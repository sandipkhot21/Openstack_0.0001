#ifndef __ASM_GENERIC_LINKAGE_H
#define __ASM_GENERIC_LINKAGE_H
/*
 * linux/linkage.h provides reasonable defaults.
 * an architecture can override them by providing its own version.
 */

#endif /* __ASM_GENERIC_LINKAGE_H */
