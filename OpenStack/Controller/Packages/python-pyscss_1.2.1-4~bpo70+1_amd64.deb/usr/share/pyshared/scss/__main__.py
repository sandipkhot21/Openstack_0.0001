import scss.tool

scss.tool.main()
