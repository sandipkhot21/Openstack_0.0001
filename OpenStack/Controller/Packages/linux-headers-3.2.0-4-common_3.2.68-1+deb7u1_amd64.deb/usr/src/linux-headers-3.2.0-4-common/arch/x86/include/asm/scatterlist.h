#ifndef _ASM_X86_SCATTERLIST_H
#define _ASM_X86_SCATTERLIST_H

#include <asm-generic/scatterlist.h>

#define ARCH_HAS_SG_CHAIN

#endif /* _ASM_X86_SCATTERLIST_H */
