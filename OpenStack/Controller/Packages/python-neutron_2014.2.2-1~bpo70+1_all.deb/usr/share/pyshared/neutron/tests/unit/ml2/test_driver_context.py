# Copyright (c) 2013 OpenStack Foundation
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import mock

from neutron.common import constants
from neutron.extensions import portbindings
from neutron.plugins.ml2 import driver_context
from neutron.tests import base


class TestDvrPortContext(base.BaseTestCase):

    def test_host(self):
        plugin = mock.Mock()
        plugin_context = mock.Mock()
        network = mock.MagicMock()
        binding = mock.Mock()

        port = {'device_owner': constants.DEVICE_OWNER_DVR_INTERFACE}
        binding.host = 'foohost'

        with mock.patch.object(driver_context.db, 'get_network_segments'):
            ctx = driver_context.DvrPortContext(plugin,
                                                plugin_context,
                                                port,
                                                network,
                                                binding)
        self.assertEqual('foohost', ctx.host)

    def test_host_super(self):
        plugin = mock.Mock()
        plugin_context = mock.Mock()
        network = mock.MagicMock()
        binding = mock.Mock()

        port = {'device_owner': 'compute',
                portbindings.HOST_ID: 'host'}
        binding.host = 'foohost'

        with mock.patch.object(driver_context.db, 'get_network_segments'):
            ctx = driver_context.DvrPortContext(plugin,
                                                plugin_context,
                                                port,
                                                network,
                                                binding)
        self.assertEqual('host', ctx.host)

    def test_status(self):
        plugin = mock.Mock()
        plugin_context = mock.Mock()
        network = mock.MagicMock()
        binding = mock.Mock()

        port = {'device_owner': constants.DEVICE_OWNER_DVR_INTERFACE}
        binding.status = 'foostatus'

        with mock.patch.object(driver_context.db, 'get_network_segments'):
            ctx = driver_context.DvrPortContext(plugin,
                                                plugin_context,
                                                port,
                                                network,
                                                binding)
        self.assertEqual('foostatus', ctx.status)

    def test_status_super(self):
        plugin = mock.Mock()
        plugin_context = mock.Mock()
        network = mock.MagicMock()
        binding = mock.Mock()

        port = {'device_owner': 'compute',
                'status': 'status'}
        binding.status = 'foostatus'

        with mock.patch.object(driver_context.db, 'get_network_segments'):
            ctx = driver_context.DvrPortContext(plugin,
                                                plugin_context,
                                                port,
                                                network,
                                                binding)
        self.assertEqual('status', ctx.status)
