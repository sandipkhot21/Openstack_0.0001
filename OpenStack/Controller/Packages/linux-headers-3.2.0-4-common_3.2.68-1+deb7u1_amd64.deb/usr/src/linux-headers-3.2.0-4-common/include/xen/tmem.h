#ifndef _XEN_TMEM_H
#define _XEN_TMEM_H
/* defined in drivers/xen/tmem.c */
extern int tmem_enabled;
#endif /* _XEN_TMEM_H */
