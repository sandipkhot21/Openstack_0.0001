__version__ = '0.5.4'

from .region import CacheRegion, register_backend, make_region
