import os

def resource_string(package_or_requirement, resource_name):
    return file(os.path.join("/usr/share/python-pycryptopp/%s" % resource_name)).read()

def resource_listdir(package_or_requirement, resource_name):
    return os.listdir("/usr/share/python-pycryptopp/%s" % resource_name)
