.. title:: MochiKit.Position - DOM Position manipulation API

Name
====

MochiKit.Position - DOM Position manipulation API


Synopsis
========

This module is experimental and is present in MochiKit 1.4+ only. No
functions are currently exported from this module. Documentation is
forthcoming.


Copyright
=========

Copyright 2005-2006 Bob Ippolito <bob@redivi.com>, and others. 
This program is dual-licensed free
software; you can redistribute it and/or modify it under the terms of
the `MIT License`_ or the `Academic Free License v2.1`_.

.. _`MIT License`: http://www.opensource.org/licenses/mit-license.php
.. _`Academic Free License v2.1`: http://www.opensource.org/licenses/afl-2.1.php
