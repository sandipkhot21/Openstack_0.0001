import unittest

class T(unittest.TestCase):
    def test_load_dll_twice(self):
        pass
