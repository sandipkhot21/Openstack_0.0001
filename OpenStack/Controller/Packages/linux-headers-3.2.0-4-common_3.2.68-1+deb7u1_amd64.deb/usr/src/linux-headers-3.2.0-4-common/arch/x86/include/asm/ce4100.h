#ifndef _ASM_CE4100_H_
#define _ASM_CE4100_H_

int ce4100_pci_init(void);

#endif
