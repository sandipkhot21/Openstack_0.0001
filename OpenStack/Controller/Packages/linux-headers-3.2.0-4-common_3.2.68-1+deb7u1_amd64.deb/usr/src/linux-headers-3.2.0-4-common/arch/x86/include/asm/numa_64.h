#ifndef _ASM_X86_NUMA_64_H
#define _ASM_X86_NUMA_64_H

extern unsigned long numa_free_all_bootmem(void);

#endif /* _ASM_X86_NUMA_64_H */
