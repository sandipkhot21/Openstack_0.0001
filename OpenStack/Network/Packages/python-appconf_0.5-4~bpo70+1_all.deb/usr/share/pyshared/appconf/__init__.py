from __future__ import absolute_import
from .base import AppConf  # noqa

# following PEP 386
__version__ = "0.5"
