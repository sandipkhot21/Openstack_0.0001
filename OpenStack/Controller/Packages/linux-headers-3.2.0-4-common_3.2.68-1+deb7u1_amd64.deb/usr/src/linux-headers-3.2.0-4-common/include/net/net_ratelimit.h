#ifndef _LINUX_NET_RATELIMIT_H
#define _LINUX_NET_RATELIMIT_H

#include <linux/ratelimit.h>

extern struct ratelimit_state net_ratelimit_state;

#endif	/* _LINUX_NET_RATELIMIT_H */
