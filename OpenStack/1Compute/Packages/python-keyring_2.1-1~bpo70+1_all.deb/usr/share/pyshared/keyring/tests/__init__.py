import logging
import sys

logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
