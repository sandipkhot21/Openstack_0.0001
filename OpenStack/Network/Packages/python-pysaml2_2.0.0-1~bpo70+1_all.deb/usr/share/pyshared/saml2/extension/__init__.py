# metadata extensions mainly
__author__ = 'rolandh'
__all__ = ["dri", "mdrpi", "mdui", "shibmd", "idpdisc", 'algsupport',
           'mdattr', 'ui']