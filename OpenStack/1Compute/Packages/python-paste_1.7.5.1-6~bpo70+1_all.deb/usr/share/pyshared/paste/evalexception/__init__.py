# (c) 2005 Ian Bicking and contributors; written for Paste (http://pythonpaste.org)
# Licensed under the MIT license: http://www.opensource.org/licenses/mit-license.php
"""
An exception handler for interactive debugging
"""
from paste.evalexception.middleware import EvalException

