#ifndef CRYPTO_WQ_H
#define CRYPTO_WQ_H

#include <linux/workqueue.h>

extern struct workqueue_struct *kcrypto_wq;
#endif
