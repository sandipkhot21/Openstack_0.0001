/*
 * Arch specific extensions to struct device
 *
 * This file is released under the GPLv2
 */
#ifndef _ASM_GENERIC_DEVICE_H
#define _ASM_GENERIC_DEVICE_H

struct dev_archdata {
};

struct pdev_archdata {
};

#endif /* _ASM_GENERIC_DEVICE_H */
