__author__ = 'rolandh'

COC = "http://www.geant.net/uri/dataprotection-code-of-conduct/v1"

RELEASE = {
    "": ["eduPersonTargetedID"],
    COC: ["eduPersonPrincipalName", "eduPersonScopedAffiliation", "mail",
          "displayName", "schacHomeOrganization"]
}

