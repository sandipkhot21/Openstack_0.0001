"""
Version information for PyGraphviz, created during installation.

Do not add this file to the repository.

"""

__version__ = '1.1'
__revision__ = None
__date__ = 'Sat May 14 12:12:14 2011'

