#ifdef CONFIG_X86_32
# include "mmzone_32.h"
#else
# include "mmzone_64.h"
#endif
