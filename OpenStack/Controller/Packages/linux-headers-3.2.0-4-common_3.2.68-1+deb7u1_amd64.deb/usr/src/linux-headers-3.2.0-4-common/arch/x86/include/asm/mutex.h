#ifdef CONFIG_X86_32
# include "mutex_32.h"
#else
# include "mutex_64.h"
#endif
