# -*- coding: utf-8 -*-
#  Created by Roland Hedberg 
#  Copyright (c) 2009 Umeå Universitet. All rights reserved.
